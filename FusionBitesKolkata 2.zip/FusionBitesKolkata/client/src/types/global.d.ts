interface Window {
  emailjs: typeof import('@emailjs/browser');
}